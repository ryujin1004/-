# 나의 방 - 개인 홈페이지

## 파일 구성
- `index.html` — 메인 페이지
- `style.css`  — 디자인
- `game.js`    — 뱀게임
- `images/`    — 그림 넣는 폴더 (직접 만들어서 사용)

## Netlify 배포 방법

1. https://netlify.com 에서 회원가입 (GitHub 계정으로도 가능)
2. 대시보드에서 **"Add new site" → "Deploy manually"** 클릭
3. 이 폴더(mysite) 전체를 드래그앤드롭
4. 완료! 자동으로 주소가 생성됩니다

## 내용 수정하기

### 사이트 이름 바꾸기
`index.html` 에서 "나의 방" 을 원하는 이름으로 교체

### 프로필 수정
`index.html` 의 `id="profile"` 섹션 안 내용 수정

### 갤러리에 그림 넣기
`images/` 폴더에 이미지 파일 넣고 아래처럼 교체:
```html
<div class="gallery-item">
  <img src="images/작품1.png" alt="작품 설명">
</div>
```

### 마퀴(흐르는 텍스트) 수정
`index.html` 에서 `.marquee` 클래스 안의 텍스트 수정

### 색상 바꾸기
`style.css` 맨 위 `:root { }` 안의 색상값 수정:
- `--pink` : 포인트 색 (기본 #ff6eb4)
- `--yellow`: 강조 색 (기본 #ffe566)
- `--cyan`  : 링크/포인트2 (기본 #66ffee)
- `--purple`: 보더 색 (기본 #c084fc)

## 방명록 실제 연동
Netlify에 배포하면 `<form data-netlify="true">` 가 자동으로 활성화됩니다.
Netlify 대시보드 → Forms 에서 제출된 글을 확인할 수 있어요.
